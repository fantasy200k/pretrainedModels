This directory stores models and pre-trained weights.
All pre-trained things can be downloaded [here](https://drive.google.com/drive/folders/1kBvOL019Gcx00vwUM1BhtaoWQDlfPPim?usp=sharing).
